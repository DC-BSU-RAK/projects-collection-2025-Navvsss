package com.example.fuelcostcalculator

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var editDistance: EditText
    private lateinit var editEfficiency: EditText
    private lateinit var editPrice: EditText
    private lateinit var btnCalculate: Button
    private lateinit var textResult: TextView
    private lateinit var btnPreferences: Button
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editDistance = findViewById(R.id.editDistance)
        editEfficiency = findViewById(R.id.editEfficiency)
        editPrice = findViewById(R.id.editPrice)
        btnCalculate = findViewById(R.id.btnCalculate)
        textResult = findViewById(R.id.textResult)
        btnPreferences = findViewById(R.id.btnPreferences)

        prefs = getSharedPreferences("user_prefs", MODE_PRIVATE)
        val savedPrice = prefs.getString("preferred_price", "")
        if (!savedPrice.isNullOrEmpty()) {
            editPrice.setText(savedPrice)
        }

        btnCalculate.setOnClickListener { calculateFuelCost() }
        btnPreferences.setOnClickListener {
            startActivity(Intent(this, PreferencesActivity::class.java))
        }
    }

    private fun calculateFuelCost() {
        val distanceStr = editDistance.text.toString()
        val efficiencyStr = editEfficiency.text.toString()
        val priceStr = editPrice.text.toString()

        if (distanceStr.isEmpty() || efficiencyStr.isEmpty() || priceStr.isEmpty()) {
            textResult.text = "Please enter all fields"
            return
        }

        val distance = distanceStr.toDoubleOrNull()
        val efficiency = efficiencyStr.toDoubleOrNull()
        val price = priceStr.toDoubleOrNull()

        if (distance == null || efficiency == null || price == null || efficiency <= 0) {
            textResult.text = "Invalid input"
            return
        }

        val cost = (distance / efficiency) * price
        textResult.text = "Estimated Cost: %.2f".format(cost)
    }
}
