package com.example.fuelcostcalculator

import android.content.SharedPreferences
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class PreferencesActivity : AppCompatActivity() {

    private lateinit var editPreferredPrice: EditText
    private lateinit var btnSavePref: Button
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preferences)

        editPreferredPrice = findViewById(R.id.editPreferredPrice)
        btnSavePref = findViewById(R.id.btnSavePref)

        prefs = getSharedPreferences("user_prefs", MODE_PRIVATE)
        editPreferredPrice.setText(prefs.getString("preferred_price", ""))

        btnSavePref.setOnClickListener {
            val price = editPreferredPrice.text.toString()
            if (price.isNotEmpty()) {
                prefs.edit().putString("preferred_price", price).apply()
                Toast.makeText(this, "Preference Saved", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
