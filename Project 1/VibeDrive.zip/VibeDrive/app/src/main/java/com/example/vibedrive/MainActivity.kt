package com.example.vibedrive

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var groupMood: RadioGroup
    private lateinit var groupTerrain: RadioGroup
    private lateinit var groupMusic: RadioGroup
    private lateinit var btnCalculate: Button
    private lateinit var textResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        groupMood = findViewById(R.id.groupMood)
        groupTerrain = findViewById(R.id.groupTerrain)
        groupMusic = findViewById(R.id.groupMusic)
        btnCalculate = findViewById(R.id.btnCalculate)
        textResult = findViewById(R.id.textResult)

        btnCalculate.setOnClickListener {
            showDriveMatch()
        }
    }

    private fun showDriveMatch() {
        val mood = getSelectedEmoji(groupMood)
        val terrain = getSelectedEmoji(groupTerrain)
        val music = getSelectedEmoji(groupMusic)

        if (mood == null || terrain == null || music == null) {
            Toast.makeText(this, "Please select all options!", Toast.LENGTH_SHORT).show()
            return
        }

        val matchDescription = when {
            mood == "😎" && terrain == "🏙️" && music == "🎶" -> "Urban Cruiser: Cool, relaxed, and smooth."
            mood == "🤩" && terrain == "🌄" && music == "🎸" -> "Adventure Seeker: You live for the thrill!"
            mood == "😡" && terrain == "🛣️" && music == "🔊" -> "Speed Demon: Fast, loud, and wild!"
            mood == "😴" && terrain == "❄️" && music == "🎻" -> "Snow Dreamer: Calm rides through frozen lands."
            else -> "Unique Driver: Your drive has no limits."
        }

        // Show modal (custom AlertDialog)
        val dialogView = LayoutInflater.from(this).inflate(android.R.layout.simple_list_item_1, null)
        val dialogText = dialogView.findViewById<TextView>(android.R.id.text1)
        dialogText.text = "$mood $terrain $music\n\n$matchDescription"
        dialogText.textSize = 20f
        dialogText.setPadding(32, 32, 32, 32)

        AlertDialog.Builder(this)
            .setTitle("Your Drive Match")
            .setView(dialogView)
            .setPositiveButton("OK", null)
            .show()

        textResult.text = "$matchDescription"
    }

    private fun getSelectedEmoji(group: RadioGroup): String? {
        val selectedId = group.checkedRadioButtonId
        if (selectedId == -1) return null
        val selectedButton = findViewById<RadioButton>(selectedId)
        return selectedButton.text.toString()
    }
}
